<?php 
include("db.php");
include("connect.php");
session_start();



// Get cart count
$cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;



?>



<!DOCTYPE HTML>
<html>
<head>
	<title>Vendor Store</title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Rokkitt:100,300,400,700" rel="stylesheet">
	
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/ionicons.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/flexslider.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
		
<div class="colorlib-loader"></div>

<div id="page">
	<nav class="colorlib-nav" role="navigation">
		<div class="top-menu">
			<div class="container">
				<div class="row">
					<div class="col-sm-7 col-md-9">
						<div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
					</div>
					<div class="col-sm-5 col-md-3">
			            <form action="#" class="search-wrap">
			               <div class="form-group">
			                  <input type="search" class="form-control search" placeholder="Search">
			                  <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
			               </div>
			            </form>
			         </div>
		        </div>
				<div class="row">
					<div class="col-sm-12 text-left menu-1">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li class="has-dropdown active">
								<a href="men.php">Men</a>
								<ul class="dropdown">
									<li><a href="cart.php">Shopping Cart</a></li>
									<li><a href="checkout.php">Checkout</a></li>
									<li><a href="wishlist.php">Wishlist</a></li>
								</ul>
							</li>
							<li><a href="women.php">Women</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="contact.php">Contact</a></li>
							<li class="cart"><a href="cart.php"><i class="icon-shopping-cart"></i> Cart [<span id="cart-count">0</span>]</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</nav>

	<div class="breadcrumbs">
		<div class="container">
			<div class="row">
				<div class="col">
					<p class="bread"><span><a href="men.php">Men</a></span> / <span>Kid T-Shirts</span></p>
				</div>
			</div>
		</div>
	</div>

	<div class="colorlib-product">
	    <div class="container">
	        <div class="row">
	            <div class="col-sm-8 offset-sm-2 text-center colorlib-heading colorlib-heading-sm">
	                <h2>Kid T-Shirts</h2>
	            </div>
	        </div>
	        <div class="row row-pb-md">

	            <?php
	            $query = mysqli_query($connect, 'SELECT * FROM kidtshirts');
	            while ($row = mysqli_fetch_assoc($query)) {
	                $id = $row['id'];
	                $image1 = $row['image1'];
	                $image2 = $row['image2'];
	                $title = $row['title'];
	                $price = $row['price'];
	            ?>
	                <div class="col-md-3 col-lg-3 mb-4 text-center">
	                    <div class="product-entry border">
	                        <a href="kidshirt<?php echo $id; ?>.php" class="prod-img">
	                            <div class="product-image">
	                                <img src="images/kids-shirts/<?php echo $image1; ?>" class="img-fluid main-img" alt="<?php echo $title; ?>">
	                                <img src="images/kids-shirts/<?php echo $image2; ?>" class="img-fluid hover-img" alt="<?php echo $title; ?>">
	                            </div>
	                        </a>
	                        <div class="desc">
	                            <h2><a href="kidshirt<?php echo $id; ?>.php"><?php echo $title; ?></a></h2>
	                            <span class="price">$<?php echo $price; ?></span>
	                        </div>
	                    </div>
	                </div>
	            <?php } ?>

	        </div>
	    </div>
	</div>
</div>

<script>
  function changeQuantity(change) {
    let qtyInput = document.getElementById("quantity");
    let current = parseInt(qtyInput.value);
    if (current + change >= 1) {
      qtyInput.value = current + change;
    }
  }

  function addToCart() {
    let product = {
      name: "Exclusive Round Neck Printed Tee Shirt For Mens",
      price: 45.00,
      size: document.getElementById("size").value,
      color: document.querySelector(".color-option.active").getAttribute("data-color"),
      quantity: parseInt(document.getElementById("quantity").value),
      image: "images/men-shirts/<?php echo $image1; ?>"
    };

    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(product);
    localStorage.setItem("cart", JSON.stringify(cart));

    document.getElementById("cart-count").innerText = cart.length;
    alert("Item added to cart!");
  }

  function buyNow() {
    let product = {
      name: "Exclusive Round Neck Printed Tee Shirt For Mens",
      price: 45.00,
      size: document.getElementById("size").value,
      color: document.querySelector(".color-option.active").getAttribute("data-color"),
      quantity: parseInt(document.getElementById("quantity").value),
      image: "images/men-shirts/<?php echo $image1; ?>"
    };

    // Save this product as a "buy now" product
    localStorage.setItem("buyNowProduct", JSON.stringify(product));

    // Redirect to checkout page
    window.location.href = "checkout.php";
  }

  // Update cart count on load
  document.addEventListener("DOMContentLoaded", () => {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    document.getElementById("cart-count").  innerText = cart.length;
  });

  // Handle color selection
  document.querySelectorAll(".color-option").forEach(option => {
    option.addEventListener("click", function() {
      document.querySelectorAll(".color-option").forEach(c => c.classList.remove("active"));
      this.classList.add("active");
    });
  });
</script>

<!-- JS -->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.easing.1.3.js"></script>
<script src="js/jquery.waypoints.min.js"></script>
<script src="js/jquery.flexslider-min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.magnific-popup.min.js"></script>
<script src="js/magnific-popup-options.js"></script>
<script src="js/bootstrap-datepicker.js"></script>
<script src="js/jquery.stellar.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>

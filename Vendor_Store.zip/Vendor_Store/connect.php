<?php

$con=mysqli_connect('localhost','root','','ecommerce2');
if($con){

    // echo "connected....";
    // die(mysqli_error($con));

    
}
?>
<?php

include("db.php");
include("connect.php");

session_start();
// include("connect.php");

// ✅ only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$product = mysqli_fetch_assoc(mysqli_query($connect, "SELECT * FROM products WHERE id=$id"));

if (isset($_POST['update_product'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $oldprice = $_POST['oldprice'];

    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$image);
        $update = "UPDATE products SET title='$title', price='$price', oldprice='$oldprice', image='$image' WHERE id=$id";
    } else {
        $update = "UPDATE products SET title='$title', price='$price', oldprice='$oldprice' WHERE id=$id";
    }

    mysqli_query($connect, $update);
    header("Location: manage-products.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Product</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Edit Product</h2>
  <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
      <label>Product Title</label>
      <input type="text" name="title" class="form-control" value="<?php echo $title; ?>" required>
    </div>
    <div class="mb-3">
      <label>Price</label>
      <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $product['price']; ?>" required>
    </div>
    <div class="mb-3">
      <label>Old Price</label>
      <input type="number" step="0.01" name="oldprice" class="form-control" value="<?php echo $product['oldprice']; ?>">
    </div>
    <div class="mb-3">
      <label>Change Image</label><br>
      <img src="uploads/<?php echo $product['image']; ?>" width="80"><br><br>
      <input type="file" name="image" class="form-control">
    </div>
    <button class="btn btn-success" type="submit" name="update_product">Update Product</button>
    <a href="manage-products.php" class="btn btn-secondary">Cancel</a>
  </form>
</div>
</body>
</html>

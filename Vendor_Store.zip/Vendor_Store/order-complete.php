<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Order Complete</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">

  <style>
    .order-complete {
      text-align: center;
      padding: 60px 20px;
    }
    .order-complete h1 {
      color: #28a745;
      font-size: 2.5rem;
      margin-bottom: 20px;
    }
    .order-complete p {
      font-size: 1.2rem;
      margin-bottom: 15px;
    }
    .order-details {
      margin: 30px auto;
      max-width: 600px;
      text-align: left;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      background: #f9f9f9;
    }
    .order-details h4 {
      margin-bottom: 15px;
      border-bottom: 1px solid #ddd;
      padding-bottom: 10px;
    }
    .order-details .row {
      margin-bottom: 8px;
    }
    .btn-back {
      margin-top: 20px;
    }
  </style>
</head>
<body>

  <!-- Navbar (same as other pages) -->
  <nav class="colorlib-nav" role="navigation">
    <div class="top-menu">
      <div class="container">
        <div class="row">
          <div class="col-sm-7 col-md-9">
            <div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
          </div>
          <div class="col-sm-5 col-md-3">
            <form action="#" class="search-wrap">
              <div class="form-group">
                <input type="search" class="form-control search" placeholder="Search">
                <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
              </div>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-left menu-1">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li><a href="men.php">Men</a></li>
              <li><a href="women.php">Women</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li class="cart"><a href="cart.php"><i class="icon-shopping-cart"></i> Cart [<span id="cart-count">0</span>]</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- Order Complete Section -->
  <div class="container order-complete">
    <h1>🎉 Thank You!</h1>
    <p>Your order has been placed successfully.</p>
    <p>We’ll send you a confirmation email with tracking details shortly.</p>

    <div class="order-details" id="order-details">
      <!-- Order details will be injected here -->
    </div>

    <a href="index.php" class="btn btn-primary btn-back">Back to Home</a>
  </div>

  <script>
    document.addEventListener("DOMContentLoaded", () => {
      let product = JSON.parse(localStorage.getItem("buyNowProduct"));
      let detailsBox = document.getElementById("order-details");
      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      document.getElementById("cart-count").innerText = cart.length;

      if (product) {
        let details = `
          <h4>Order Summary</h4>
          <div class="row">
            <div class="col-6"><strong>Product:</strong></div>
            <div class="col-6">${product.name}</div>
          </div>
          <div class="row">
            <div class="col-6"><strong>Size:</strong></div>
            <div class="col-6">${product.size}</div>
          </div>
          <div class="row">
            <div class="col-6"><strong>Color:</strong></div>
            <div class="col-6">${product.color}</div>
          </div>
          <div class="row">
            <div class="col-6"><strong>Quantity:</strong></div>
            <div class="col-6">${product.quantity}</div>
          </div>
          <div class="row">
            <div class="col-6"><strong>Total Price:</strong></div>
            <div class="col-6">$${(product.price * product.quantity).toFixed(2)}</div>
          </div>
        `;
        detailsBox.innerHTML = details;
      } else {
        detailsBox.innerHTML = "<p>No order details found.</p>";
      }
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php 

include("db.php");
include("connect.php");

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Cart</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Rokkitt:100,300,400,700" rel="stylesheet">

  <!-- Theme CSS -->
  <link rel="stylesheet" href="css/style.css">

  <style>
    .cart-container {
      padding: 30px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
    }
    table thead {
      background: #f8f9fa;
      border-bottom: 2px solid #ddd;
    }
    table th, table td {
      padding: 12px;
      text-align: center;
      vertical-align: middle;
    }
    table td img {
      width: 80px;
      height: auto;
      border-radius: 6px;
    }
    .btn-remove {
      background: #dc3545;
      color: #fff;
      border: none;
      padding: 6px 12px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
    }
    .btn-remove:hover {
      background: #b02a37;
    }
    .qty-input {
      width: 60px;
      text-align: center;
    }
    .total-row {
      font-weight: bold;
      background: #f8f9fa;
    }
    .checkout-btn {
      margin-top: 20px;
      display: inline-block;
      padding: 12px 25px;
      background: #198754;
      color: #fff;
      font-size: 16px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      text-decoration: none;
    }
    .checkout-btn:hover {
      background: #157347;
    }
  </style>
</head>
<body>

  <!-- SAME NAVBAR -->
  <nav class="colorlib-nav" role="navigation">
    <div class="top-menu">
      <div class="container">
        <div class="row">
          <div class="col-sm-7 col-md-9">
            <div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
          </div>
          <div class="col-sm-5 col-md-3">
            <form action="#" class="search-wrap">
              <div class="form-group">
                <input type="search" class="form-control search" placeholder="Search">
                <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
              </div>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-left menu-1">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li class="has-dropdown">
                <a href="men.php">Men</a>
                <ul class="dropdown">
                  <li><a href="product-detail.php">Product Detail</a></li>
                  <li class="active"><a href="cart.php">Shopping Cart</a></li>
                  <li><a href="checkout.php">Checkout</a></li>
                  <li><a href="order-complete.php">Order Complete</a></li>
                  <li><a href="add-to-wishlist.php">Wishlist</a></li>
                </ul>
              </li>
              <li><a href="women.php">Women</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contact.php">Contact</a></li>
              <!-- ✅ Dynamic cart count -->
              <li class="cart active"><a href="cart.php"><i class="icon-shopping-cart"></i> Cart [<span id="cartCount">0</span>]</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- CART DESIGN -->
  <div class="container cart-container">
    <h2 class="mb-4">🛒 Shopping Cart</h2>
    <div id="cartContainer"></div>
    <div id="checkoutBtnContainer" class="text-end"></div>
  </div>

<script>
  function loadCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let container = document.getElementById("cartContainer");
    let cartCount = document.getElementById("cartCount");
    let checkoutBtnContainer = document.getElementById("checkoutBtnContainer");

    // ✅ Update navbar cart count
    cartCount.textContent = cart.length;

    if (cart.length === 0) {
      container.innerHTML = "<p>Your cart is empty.</p>";
      checkoutBtnContainer.innerHTML = "";
      return;
    }

    let table = `
      <table class="table table-bordered align-middle">
        <thead>
          <tr>
            <th>Product</th>
            <th>Details</th>
            <th>Size</th>
            <th>Color</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Remove</th>
          </tr>
        </thead>
        <tbody>
    `;

    let grandTotal = 0;

    cart.forEach((item, index) => {
      let itemTotal = item.price * item.quantity;
      grandTotal += itemTotal;

      table += `
        <tr>
          <td><img src="${item.image}" alt="Product"></td>
          <td>${item.name}</td>
          <td>${item.size}</td>
          <td>${item.color}</td>
          <td>
            <input type="number" class="qty-input" value="${item.quantity}" min="1" onchange="updateQuantity(${index}, this.value)">
          </td>
          <td>$${itemTotal.toFixed(2)}</td>
          <td><button class="btn-remove" onclick="removeItem(${index})">Remove</button></td>
        </tr>
      `;
    });

    // ✅ Add grand total row
    table += `
        <tr class="total-row">
          <td colspan="5" class="text-end">Grand Total:</td>
          <td colspan="2">$${grandTotal.toFixed(2)}</td>
        </tr>
    `;

    table += `</tbody></table>`;
    container.innerHTML = table;

    // ✅ Checkout button
    checkoutBtnContainer.innerHTML = `
      <a href="checkout.php" class="checkout-btn">Proceed to Checkout</a>
    `;
  }

  function removeItem(index) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.splice(index, 1);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
  }

  function updateQuantity(index, newQty) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    if (newQty < 1) newQty = 1;
    cart[index].quantity = parseInt(newQty);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
  }

  window.onload = loadCart;
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

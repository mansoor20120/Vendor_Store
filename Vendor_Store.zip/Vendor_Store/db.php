<?php
    $connect = mysqli_connect("localhost","root","","ecommerce2");


?>
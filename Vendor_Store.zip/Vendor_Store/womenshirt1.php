<?php 

include("db.php");
include("connect.php");

?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Women's Sweat Shirt Burgandy</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Rokkitt:100,300,400,700" rel="stylesheet">

  <!-- Theme CSS -->
  <link rel="stylesheet" href="css/style.css">

  <style>
    .product-detail {
      padding: 20px;
    }
    .product-image {
      position: relative;
      width: 100%;
      max-height: 350px;
      overflow: hidden;
      border-radius: 8px;
    }
    .product-image img {
      width: 100%;
      height: auto;
      max-height: 350px;
      object-fit: contain;
      transition: opacity 0.4s ease;
    }
    .product-image .hover-img {
      position: absolute;
      top: 0;
      left: 0;
      opacity: 0;
    }
    .product-image:hover .main-img {
      opacity: 0;
    }
    .product-image:hover .hover-img {
      opacity: 1;
    }
    .color-option {
      width: 25px;
      height: 25px;
      border-radius: 50%;
      display: inline-block;
      margin-right: 8px;
      cursor: pointer;
      border: 2px solid #ddd;
    }
    .color-option.active {
      border: 2px solid #000;
    }
    .btn-custom {
      width: 130px;
      margin-right: 8px;
    }
    .quantity-selector {
      display: flex;
      align-items: center;
      margin-top: 10px;
    }
    .quantity-selector button {
      width: 30px;
      height: 30px;
      border: 1px solid #ccc;
      background: #f8f9fa;
      cursor: pointer;
    }
    .quantity-selector input {
      width: 40px;
      text-align: center;
      border: 1px solid #ccc;
      margin: 0 5px;
    }
    .old-price {
      text-decoration: line-through;
      color: #888;
      margin-right: 8px;
      font-size: 16px;
    }
    .discounted-price {
      color: #28a745;
      font-weight: bold;
      font-size: 18px;
    }
  </style>
</head>
<body>

  <!-- SAME NAVBAR -->
  <nav class="colorlib-nav" role="navigation">
    <div class="top-menu">
      <div class="container">
        <div class="row">
          <div class="col-sm-7 col-md-9">
            <div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
          </div>
          <div class="col-sm-5 col-md-3">
            <form action="#" class="search-wrap">
              <div class="form-group">
                <input type="search" class="form-control search" placeholder="Search">
                <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
              </div>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-left menu-1">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li class="has-dropdown active">
                <a href="women.php">Women</a>
                <ul class="dropdown">
                  <li><a href="product-detail.php">Product Detail</a></li>
                  <li><a href="cart.php">Shopping Cart</a></li>
                  <li><a href="checkout.php">Checkout</a></li>
                  <li><a href="order-complete.php">Order Complete</a></li>
                  <li><a href="add-to-wishlist.php">Wishlist</a></li>
                </ul>
              </li>
              <li><a href="women.php">Women</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contact.php">Contact</a></li>
              <li class="cart"><a href="cart.php"><i class="icon-shopping-cart"></i> Cart [<span id="cart-count">0</span>]</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- Product Section -->
  <div class="container product-detail mt-3">
    <div class="row">
      <!-- Product Image -->
      <div class="col-md-5">
    <?php
    // ✅ Fetch only one product by id
    $productId = 1; // You can change this or get it from URL like $_GET['id']
    $query = mysqli_query($connect, "SELECT * FROM womenshirts WHERE id = $productId LIMIT 1");

    if ($row = mysqli_fetch_assoc($query)) {
        $id       = $row['id'];
        $image1   = $row['image1'];
        $image2   = $row['image2'];
        $title    = $row['title'];
        $price    = $row['price'];
        $oldprice = $row['oldprice'];
        $smallsize = $row['smallsize'];
        $mediumsize = $row['mediumsize'];
        $largesize = $row['largesize'];
        $extralargesize = $row['extralargesize'];
        $addtocart = $row['addtocart'];
        $buynow = $row['buynow'];
    ?>
        <div class="product-image">
            <img src="images/women-shirts/<?php echo $image1; ?>" alt="Main Shirt" class="main-img">
            <img src="images/women-shirts/<?php echo $image2; ?>" alt="Hover Shirt" class="hover-img">
        </div>
    <?php } ?>
</div>


      <!-- Product Info -->
      <div class="col-md-7">
        <h4><?php echo $title; ?></h4>
        <p>
          <span class="old-price">$<?php echo $oldprice; ?></span>
          <span class="discounted-price">$<?php echo $price; ?></span>
        </p>
        <p><strong>Delivery:</strong> Free delivery within 5-7 business days</p>

        <p><strong>Choose Size:</strong></p>
        <select id="size" class="form-select w-50 mb-3">
          <option value="S"><?php echo $smallsize; ?></option>
          <option value="M"><?php echo $mediumsize; ?></option>
          <option value="L"><?php echo $largesize; ?></option>
          <option value="XL"><?php echo $extralargesize; ?></option>
        </select>

        <p><strong>Available Colors:</strong></p>
        <div>
          <span class="color-option active" style="background-color: red;" data-color="Red"></span>
          <span class="color-option" style="background-color: black;" data-color="Black"></span>
          <span class="color-option" style="background-color: blue;" data-color="Blue"></span>
        </div>

        <p class="mt-3"><strong>Quantity:</strong></p>
        <div class="quantity-selector">
          <button onclick="changeQuantity(-1)">-</button>
          <input type="text" id="quantity" value="1" readonly>
          <button onclick="changeQuantity(1)">+</button>
        </div>

        <div class="mt-3">
          <button class="btn btn-primary btn-custom" onclick="addToCart()"><?php echo $addtocart; ?></button>
          <button class="btn btn-success btn-custom" onclick="buyNow()"><?php echo $buynow; ?></button>
        </div>
      </div>
    </div>
  </div>

<script>
  function changeQuantity(change) {
    let qtyInput = document.getElementById("quantity");
    let current = parseInt(qtyInput.value);
    if (current + change >= 1) {
      qtyInput.value = current + change;
    }
  }

  function addToCart() {
    let product = {
      name: "Women's Sweat Shirt",
      price: 56.00,
      size: document.getElementById("size").value,
      color: document.querySelector(".color-option.active").getAttribute("data-color"),
      quantity: parseInt(document.getElementById("quantity").value),
      image: "images/women-shirts/<?php echo $image1; ?>"
    };

    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(product);
    localStorage.setItem("cart", JSON.stringify(cart));

    document.getElementById("cart-count").innerText = cart.length;
    alert("Item added to cart!");
  }

  function buyNow() {
    let product = {
      name: "Women's Sweat Shirt",
      price: 56.00,
      size: document.getElementById("size").value,
      color: document.querySelector(".color-option.active").getAttribute("data-color"),
      quantity: parseInt(document.getElementById("quantity").value),
      image: "images/women-shirts/<?php echo $image1; ?>"
    };

    // Save this product as a "buy now" product
    localStorage.setItem("buyNowProduct", JSON.stringify(product));

    // Redirect to checkout page
    window.location.href = "checkout.php";
  }

  // Update cart count on load
  document.addEventListener("DOMContentLoaded", () => {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    document.getElementById("cart-count").  innerText = cart.length;
  });

  // Handle color selection
  document.querySelectorAll(".color-option").forEach(option => {
    option.addEventListener("click", function() {
      document.querySelectorAll(".color-option").forEach(c => c.classList.remove("active"));
      this.classList.add("active");
    });
  });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

# 🛒 Vendor Store (E-Commerce Website)

Vendor Store is a responsive e-commerce website built with **HTML, CSS, Bootstrap, and JavaScript** for the front-end, and **PHP & MySQL** for the back-end.  
It allows users to browse products, manage a cart, and handle purchases efficiently.  

---

## ✨ Features
- Responsive design (works on desktop & mobile)
- Product listing and details
- Shopping cart functionality
- PHP & MySQL database integration
- Clean and modern UI with Bootstrap
- Fully functional CRUD operations

---

## 🛠️ Technologies Used
- **Front-end:** HTML, CSS, Bootstrap, JavaScript  
- **Back-end:** PHP  
- **Database:** MySQL  
- **Server:** XAMPP (Apache & MySQL)  

---

## 📂 Project Structure


vendor_store/

├── index.php
├── product.php
├── cart.php
├── checkout.php
├── css/
├── js/
├── images/
├── includes/
├── database/
│ └── vendor_store.sql
├── .gitignore
└── README.md


---

## ⚙️ Installation & Setup

1. Install [XAMPP](https://www.apachefriends.org/download.html) (or WAMP).  
2. Copy the `vendor_store` folder into the `htdocs` directory.  
   Example:  

C:\xampp\htdocs\vendor_store

3. Open [phpMyAdmin](http://localhost/phpmyadmin).  
4. Create a new database (e.g., `vendor_store`).  
5. Import the SQL file:  

database/vendor_store.sql

6. Start **Apache** and **MySQL** in the XAMPP Control Panel.  
7. Open the website in your browser:  



http://localhost/vendor_store
---

## 👨‍💻 Usage
- Visit the homepage and browse products.  
- Add items to the cart and proceed to checkout.  
- Database manages products, users, and orders.  

---

## 📸 Screenshots
(Add screenshots of homepage, product page, and cart here)

---

## 📜 License
This project is created for learning and demonstration purposes. You are free to use and modify it.  

---

## ⚠️ Note about `.gitignore`
This project includes a `.gitignore` file to keep the repository clean. It ignores:
- Database dumps (`*.sql`)  
- Config files (`.env`, `config.php`)  
- `vendor/` and `node_modules/` folders  
- Logs, cache, and system files  

This ensures only the **necessary source code** is uploaded to GitHub.




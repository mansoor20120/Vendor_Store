<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Checkout</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Theme (optional) -->
  <link rel="stylesheet" href="css/style.css">

  <style>
    .checkout-container { margin-top: 30px; }
    .order-summary { border: 1px solid #ddd; border-radius: 8px; padding: 20px; background: #f9f9f9; }
    .summary-row { display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
    .summary-item { display: flex; gap: 12px; align-items: center; }
    .summary-item img { width: 64px; height: 64px; object-fit: cover; border-radius: 6px; }
    .price { white-space: nowrap; }
    .place-order-btn { width: 100%; margin-top: 15px; }
    .disabled-note { font-size: .95rem; color: #6c757d; }
    .mini { font-size: .875rem; color: #6c757d; }
    .btn-outline { border: 1px solid #dee2e6; background: #fff; }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="colorlib-nav" role="navigation">
    <div class="top-menu">
      <div class="container">
        <div class="row">
          <div class="col-sm-7 col-md-9">
            <div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
          </div>
          <div class="col-sm-5 col-md-3">
            <form action="#" class="search-wrap">
              <div class="form-group d-flex">
                <input type="search" class="form-control search" placeholder="Search">
                <button class="btn btn-primary submit-search text-center" type="submit"><i class="icon-search"></i></button>
              </div>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12 text-left menu-1">
            <ul>
              <li><a href="index.php">Home</a></li>
              <li class="has-dropdown">
                <a href="men.php">Men</a>
                <ul class="dropdown">
                  <li><a href="product-detail.php">Product Detail</a></li>
                  <li><a href="cart.php">Shopping Cart</a></li>
                  <li class="active"><a href="checkout.php">Checkout</a></li>
                  <li><a href="order-complete.php">Order Complete</a></li>
                  <li><a href="add-to-wishlist.php">Wishlist</a></li>
                </ul>
              </li>
              <li><a href="women.php">Women</a></li>
              <li><a href="about.php">About</a></li>
              <li><a href="contact.php">Contact</a></li>
              <!-- support both ids so it works with your other pages -->
              <li class="cart"><a href="cart.php"><i class="icon-shopping-cart"></i> Cart [<span id="cartCount">0</span><span id="cart-count" class="d-none">0</span>]</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <!-- Checkout Section -->
  <div class="container checkout-container">
    <div class="row g-4">
      <!-- Shipping Details -->
      <div class="col-lg-7">
        <h4>Shipping Details</h4>
        <div id="alert-box" class="mb-3"></div>

        <!-- Use Bootstrap validation styling -->
        <form id="checkout-form" novalidate>
          <div class="mb-3">
            <label class="form-label" for="name">Full Name</label>
            <input type="text" id="name" class="form-control" required />
            <div class="invalid-feedback">Please enter your full name.</div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input type="email" id="email" class="form-control" required />
            <div class="invalid-feedback">Please enter a valid email (e.g., name@example.com).</div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="phone">Phone Number</label>
            <input type="tel" id="phone" class="form-control" required />
            <div class="mini">Allowed: digits, spaces, +, -, () — must have 7–15 digits.</div>
            <div class="invalid-feedback">Please enter a valid phone number (7–15 digits).</div>
          </div>

          <div class="mb-3">
            <label class="form-label" for="address">Address</label>
            <textarea id="address" class="form-control" rows="3" required></textarea>
            <div class="invalid-feedback">Please enter your street address.</div>
          </div>

          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label" for="city">City</label>
              <input type="text" id="city" class="form-control" required />
              <div class="invalid-feedback">Please enter your city.</div>
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label" for="zip">Zip / Postal Code</label>
              <input type="text" id="zip" class="form-control" required />
              <div class="invalid-feedback">Please enter a valid postal code.</div>
            </div>
          </div>
        </form>
      </div>

      <!-- Order Summary -->
      <div class="col-lg-5">
        <h4>Order Summary</h4>
        <div class="order-summary" id="order-summary">
          <!-- Injected by JS -->
        </div>
        <button class="btn btn-success place-order-btn" id="placeOrderBtn">Place Order</button>
        <div class="mt-2 text-center">
          <a class="btn btn-outline w-100" href="cart.php">Edit Cart</a>
        </div>
        <p id="disabledNote" class="mt-2 disabled-note d-none">Add items to your cart to place an order.</p>
      </div>
    </div>
  </div>

  <script>
    // Utility: set cart count in navbar (supports both IDs you've used)
    function setCartCountUI(n) {
      const el1 = document.getElementById('cartCount');
      const el2 = document.getElementById('cart-count');
      if (el1) el1.textContent = n;
      if (el2) { el2.textContent = n; el2.classList.add('d-none'); } // keep hidden if both exist
    }

    // Format price helper
    function money(n) { return '$' + Number(n).toFixed(2); }

    // Build order summary from cart or buyNowProduct
    function loadOrderSummary() {
      const buyNow = JSON.parse(localStorage.getItem('buyNowProduct'));
      const cart = JSON.parse(localStorage.getItem('cart')) || [];

      // Update navbar count using the real cart length
      setCartCountUI(cart.length);

      // Prefer buy-now if present, otherwise use cart
      const items = buyNow ? [buyNow] : cart;
      const from = buyNow ? 'buyNow' : 'cart';

      const sumEl = document.getElementById('order-summary');
      const placeBtn = document.getElementById('placeOrderBtn');
      const disabledNote = document.getElementById('disabledNote');

      if (!items || items.length === 0) {
        sumEl.innerHTML = '<p>Your cart is empty.</p>';
        placeBtn.disabled = true;
        disabledNote.classList.remove('d-none');
        return { items: [], from };
      }

      // Build list
      let subtotal = 0;
      const lines = items.map((it) => {
        const lineTotal = (Number(it.price) || 0) * (Number(it.quantity) || 1);
        subtotal += lineTotal;
        return `
          <div class="summary-row py-2 border-bottom">
            <div class="summary-item">
              <img src="${it.image}" alt="${it.name}">
              <div>
                <div class="fw-semibold">${it.name || 'Product'}</div>
                <div class="text-muted mini">
                  ${it.size ? `Size: ${it.size}` : ''} ${it.color ? ` | Color: ${it.color}` : ''}
                  ${it.quantity ? ` | Qty: ${it.quantity}` : ''}
                </div>
              </div>
            </div>
            <div class="price">${money(lineTotal)}</div>
          </div>
        `;
      }).join('');

      const shipping = 0; // set your shipping logic if needed
      const tax = 0;      // set your tax logic if needed
      const total = subtotal + shipping + tax;

      sumEl.innerHTML = `
        ${lines}
        <div class="d-flex justify-content-between pt-3"><span class="fw-semibold">Subtotal</span><span>${money(subtotal)}</span></div>
        <div class="d-flex justify-content-between"><span>Shipping</span><span>${money(shipping)}</span></div>
        <div class="d-flex justify-content-between"><span>Tax</span><span>${money(tax)}</span></div>
        <hr>
        <div class="d-flex justify-content-between fs-5"><span class="fw-bold">Total</span><span class="fw-bold">${money(total)}</span></div>
      `;

      placeBtn.disabled = false;
      disabledNote.classList.add('d-none');

      return { items, from };
    }

    // Simple validators
    function isValidEmail(v) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
    }
    function isValidPhone(v) {
      const digits = (v || '').replace(/\D/g, '');
      return digits.length >= 7 && digits.length <= 15;
    }
    function isValidZip(v) {
      return (v || '').trim().length >= 3; // simple generic check; adjust per country if needed
    }

    function showAlert(type, msg) {
      const box = document.getElementById('alert-box');
      box.innerHTML = `<div class="alert alert-${type}" role="alert">${msg}</div>`;
    }

    document.addEventListener('DOMContentLoaded', () => {
      const state = loadOrderSummary(); // {items, from}

      const form = document.getElementById('checkout-form');
      const placeBtn = document.getElementById('placeOrderBtn');

      placeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        // Bootstrap validation UX
        form.classList.add('was-validated');

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const address = document.getElementById('address').value.trim();
        const city = document.getElementById('city').value.trim();
        const zip = document.getElementById('zip').value.trim();

        let valid = true;

        if (!name) valid = false;
        if (!isValidEmail(email)) valid = false;
        if (!isValidPhone(phone)) valid = false;
        if (!address) valid = false;
        if (!city) valid = false;
        if (!isValidZip(zip)) valid = false;

        if (!state.items || state.items.length === 0) valid = false;

        if (!valid) {
          showAlert('danger', '⚠️ Please correct the highlighted fields before placing your order.');
          return;
        }

        showAlert('success', '✅ Your order has been placed successfully!');
        // Clear the right storage and go to complete page
        setTimeout(() => {
          if (state.from === 'buyNow') {
            localStorage.removeItem('buyNowProduct');
          } else {
            localStorage.removeItem('cart');
          }
          window.location.href = 'order-complete.php';
        }, 900);
      });
    });
  </script>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

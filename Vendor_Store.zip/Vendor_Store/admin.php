<?php
// admin.php
session_start();

// ✅ Block unauthorized access
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
  header("Location: admin_login.php");
  exit();
}

// ✅ DB connect
$connect = mysqli_connect("localhost", "root", "", "ecommerce2");
if (!$connect) { die("DB Connection failed: " . mysqli_connect_error()); }

// Helper
function h($v){ return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); }

// ✅ Get selected table (default)
$table = $_GET['table'] ?? 'mentshirts';

// ✅ List available tables
$tablesRes = mysqli_query($connect, "SHOW TABLES");
$tables = [];
while ($row = mysqli_fetch_row($tablesRes)) {
  $tables[] = $row[0];
}

// ✅ Fetch table columns
$colsRes = mysqli_query($connect, "SHOW COLUMNS FROM `$table`");
$columns = [];
while ($c = mysqli_fetch_assoc($colsRes)) {
  $columns[] = $c['Field'];
}

// ✅ Handle Delete
if (isset($_GET['delete'])) {
  $id = (int)$_GET['delete'];
  mysqli_query($connect, "DELETE FROM `$table` WHERE id=$id");
  header("Location: admin.php?table=$table&msg=deleted");
  exit();
}

// ✅ Handle Create / Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $id = (int)($_POST['id'] ?? 0);

  $data = [];
  foreach ($columns as $col) {
    if ($col == 'id') continue;
    if (isset($_POST[$col])) {
      $data[$col] = mysqli_real_escape_string($connect, $_POST[$col]);
    }
  }

  if ($action === 'create') {
    $keys = "`" . implode("`,`", array_keys($data)) . "`";
    $vals = "'" . implode("','", $data) . "'";
    mysqli_query($connect, "INSERT INTO `$table` ($keys) VALUES ($vals)");
    header("Location: admin.php?table=$table&msg=created");
    exit();
  }
  if ($action === 'update') {
    $updates = [];
    foreach ($data as $k=>$v) {
      $updates[] = "`$k`='$v'";
    }
    mysqli_query($connect, "UPDATE `$table` SET " . implode(",", $updates) . " WHERE id=$id");
    header("Location: admin.php?table=$table&msg=updated");
    exit();
  }
}

// ✅ Prefill Edit
$editItem = null;
if (isset($_GET['edit'])) {
  $eid = (int)$_GET['edit'];
  $q = mysqli_query($connect, "SELECT * FROM `$table` WHERE id=$eid LIMIT 1");
  $editItem = mysqli_fetch_assoc($q) ?: null;
}

// ✅ Fetch rows
$items = mysqli_query($connect, "SELECT * FROM `$table` ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin • Vendor Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Fonts & Bootstrap like your site -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Rokkitt:100,300,400,700" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/ionicons.min.css">
  <link rel="stylesheet" href="css/style.css">

  <style>
    body { background:#f7f8fa; }
    .admin-wrap { min-height:100vh; display:grid; grid-template-columns:260px 1fr; }
    .admin-sidebar {
      background:#111; color:#fff; padding:20px; position:sticky; top:0; height:100vh;
    }
    .admin-sidebar .brand { font-weight:700; font-size:20px; margin-bottom:20px; }
    .admin-sidebar a { color:#cfd3da; text-decoration:none; display:block; padding:10px 12px; border-radius:10px; margin-bottom:6px; }
    .admin-sidebar a.active, .admin-sidebar a:hover { background:#1e1e1e; color:#fff; }
    .admin-content { padding:24px; }
    .card { border:0; border-radius:18px; box-shadow:0 8px 24px rgba(0,0,0,.06); }
    .form-control { border-radius:12px; }
    .table thead th { background:#fafafa; }
    .topbar {
      background:#fff; padding:14px 20px; border-radius:18px;
      box-shadow:0 8px 24px rgba(0,0,0,.06);
      display:flex; align-items:center; justify-content:space-between;
      margin-bottom:18px;
    }
    @media (max-width:992px){
      .admin-wrap { grid-template-columns:1fr; }
      .admin-sidebar { position:relative; height:auto; border-radius:0 0 18px 18px; }
    }
  </style>
</head>
<body>

<nav class="colorlib-nav" style="background:#fff;border-bottom:1px solid #eee;">
  <div class="top-menu">
    <div class="container">
      <div class="row align-items-center">
        <div class="col">
          <div id="colorlib-logo"><a href="index.php">Vendor Store</a></div>
        </div>
        <div class="col-auto">
          <a class="btn btn-outline-dark btn-sm" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
</nav>

<div class="container-fluid mt-3">
  <div class="admin-wrap">
    <!-- Sidebar -->
    <aside class="admin-sidebar rounded-4">
      <div class="brand">Admin Panel</div>
      <?php foreach($tables as $t): ?>
        <a href="admin.php?table=<?php echo h($t); ?>" 
           class="<?php echo $t==$table?'active':''; ?>">
          <i class="icon ion-ios-pricetags"></i> <?php echo ucfirst($t); ?>
        </a>
      <?php endforeach; ?>
      <hr style="border-color:#2a2a2a;">
      <a href="index.php"><i class="icon ion-ios-home"></i> Back to Website</a>
      <a href="logout.php"><i class="icon ion-log-out"></i> Logout</a>
    </aside>

    <!-- Content -->
    <main class="admin-content">
      <div class="topbar">
        <h4 class="m-0">Manage: <?php echo ucfirst(h($table)); ?></h4>
        <?php if(isset($_GET['msg'])): ?>
          <span class="badge bg-success"><?php echo h($_GET['msg']); ?></span>
        <?php endif; ?>
      </div>

      <!-- Create / Edit -->
      <div class="card mb-4">
        <div class="card-body">
          <h5><?php echo $editItem ? "Edit ID ".$editItem['id'] : "Add New"; ?></h5>
          <form method="post" class="row g-3">
            <?php if($editItem): ?>
              <input type="hidden" name="action" value="update">
              <input type="hidden" name="id" value="<?php echo (int)$editItem['id']; ?>">
            <?php else: ?>
              <input type="hidden" name="action" value="create">
            <?php endif; ?>

            <?php foreach($columns as $col): if($col=='id') continue; ?>
              <div class="col-md-4">
                <label class="form-label"><?php echo ucfirst($col); ?></label>
                <input type="text" name="<?php echo h($col); ?>" class="form-control"
                       value="<?php echo h($editItem[$col] ?? ''); ?>">
              </div>
            <?php endforeach; ?>

            <div class="col-12">
              <button class="btn btn-primary px-4" type="submit">
                <?php echo $editItem ? "Update" : "Create"; ?>
              </button>
              <?php if($editItem): ?>
                <a href="admin.php?table=<?php echo h($table); ?>" class="btn btn-outline-secondary">Cancel</a>
              <?php endif; ?>
            </div>
          </form>
        </div>
      </div>

      <!-- Records -->
      <div class="card">
        <div class="card-body">
          <h5>All Records</h5>
          <div class="table-responsive">
            <table class="table align-middle">
              <thead>
                <tr>
                  <?php foreach($columns as $c): ?>
                    <th><?php echo ucfirst($c); ?></th>
                  <?php endforeach; ?>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php while($row = mysqli_fetch_assoc($items)): ?>
                  <tr>
                    <?php foreach($columns as $c): ?>
                      <td><?php echo h($row[$c]); ?></td>
                    <?php endforeach; ?>
                    <td>
                      <a href="admin.php?table=<?php echo h($table); ?>&edit=<?php echo (int)$row['id']; ?>" 
                         class="btn btn-sm btn-outline-primary">Edit</a>
                      <a href="admin.php?table=<?php echo h($table); ?>&delete=<?php echo (int)$row['id']; ?>" 
                         onclick="return confirm('Delete this record?');"
                         class="btn btn-sm btn-outline-danger">Delete</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

    </main>
  </div>
</div>

<script src="js/bootstrap.min.js"></script>
</body>
</html>

<?php
session_start();
include("connect.php");

// ✅ only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Add Product
if (isset($_POST['add_product'])) {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $oldprice = $_POST['oldprice'];
    $image = $_FILES['image']['name'];

    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/".$image);

    $query = "INSERT INTO products (title, price, oldprice, image) 
              VALUES ('$title', '$price', '$oldprice', '$image')";
    mysqli_query($connect, $query);
    header("Location: manage-products.php");
    exit();
}

// Delete Product
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($connect, "DELETE FROM products WHERE id=$id");
    header("Location: manage-products.php");
    exit();
}

// Fetch all products
$products = mysqli_query($connect, "SELECT * FROM products ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Manage Products</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <h2>Manage Products</h2>
  <a href="admin.php" class="btn btn-secondary mb-3">⬅ Back to Dashboard</a>

  <!-- Add Product Form -->
  <div class="card mb-4">
    <div class="card-body">
      <h4>Add New Product</h4>
      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label>Product Title</label>
          <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Price</label>
          <input type="number" step="0.01" name="price" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Old Price</label>
          <input type="number" step="0.01" name="oldprice" class="form-control">
        </div>
        <div class="mb-3">
          <label>Product Image</label>
          <input type="file" name="image" class="form-control" required>
        </div>
        <button class="btn btn-primary" type="submit" name="add_product">Add Product</button>
      </form>
    </div>
  </div>

  <!-- Products Table -->
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>ID</th>
        <th>Image</th>
        <th>Title</th>
        <th>Price</th>
        <th>Old Price</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($row = mysqli_fetch_assoc($products)) { ?>
      <tr>
        <td><?php echo $row['id']; ?></td>
        <td><img src="uploads/<?php echo $row['image']; ?>" width="60"></td>
        <td><?php echo $row['title']; ?></td>
        <td>$<?php echo $row['price']; ?></td>
        <td><s>$<?php echo $row['oldprice']; ?></s></td>
        <td>
          <a href="edit-product.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
          <a href="manage-products.php?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"
             onclick="return confirm('Are you sure?')">Delete</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</body>
</html>
